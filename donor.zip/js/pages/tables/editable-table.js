$(function () {
    $('#mainTable').editableTableWidget();
});