/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","en-gb",{title:"Element Information",dialogName:"Dialogue window name",tabName:"Tab name",elementId:"Element ID",elementType:"Element type"});